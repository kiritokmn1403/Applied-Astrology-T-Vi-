Applied Astrology (T? Vi ?ng D?ng) v0.0.1 - Portable Edition
Run AppliedAstrology.exe to start.
