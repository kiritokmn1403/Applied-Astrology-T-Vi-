Applied Astrology 0.0.3 (Tu Vi Ung Dung - Buu Dinh)
Run AppliedAstrology.exe. Requires .NET Framework 4.5+ (Windows 7 SP1+). Uses Edge WebView2 when installed, otherwise IE11.
