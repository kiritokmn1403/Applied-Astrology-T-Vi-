Applied Astrology 0.0.6 (Tu Vi Ung Dung - Buu Dinh)
Run AppliedAstrology.exe. Native Windows app (WinForms + GDI+), no browser engine. Requires .NET Framework 4.5+ (Windows 7 SP1+).
